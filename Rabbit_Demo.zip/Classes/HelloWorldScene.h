#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"
#include "GameCtrl.h"
#include "editor-support/cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"


USING_NS_CC;
using namespace cocos2d::ui;

const string STR_STEP = "Step:"; //step的key
const string STR_BEST = "Best:"; //bestStep的key

class HelloWorld : public cocos2d::Layer
{
public:
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene();

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    
    // implement the "static create()" method manually
    CREATE_FUNC(HelloWorld);
    
public:
    bool onTouchBeganCallBack(cocos2d::Touch* t,cocos2d::Event* event);
    virtual void onEnter();
    virtual void onExit();
private:
    //存放所有子节点
    Node* m_pNodes;
    
    //存放兔子的节点
    Node* m_pNode_rabbit;
    
    //存放障碍的节点的容器
    cocos2d::Vector<Node* > m_pNodes_obstacle;
    
    //游戏逻辑控制
    GameCtrl* m_ctrl;
    
    //随机设置障碍
    void setRandStones(int num);
    
    //Step Text
    Text* m_pText_curStep;
    
    //BestStep Text
    Text* m_pText_bestStep;

    //设置Text
    void setText(Text* pTxt,int num);

    
};

#endif // __HELLOWORLD_SCENE_H__
