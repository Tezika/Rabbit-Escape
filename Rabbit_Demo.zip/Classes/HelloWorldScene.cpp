#include "HelloWorldScene.h"

//至少8个障碍
const int NUM_INITSTONE = 8;
//变化的障碍数
const int NUM_DEATALSTONE = 4;

USING_NS_CC;


Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }
    //获取和添加场景节点
    auto pNode_scene = CSLoader::createNode("MainScene.csb");
    this->addChild(pNode_scene);
    
    
    //获取所有子节点
    m_pNodes= pNode_scene->getChildByName("Sprite_bg");
    
    //分别的到兔子和障碍节点
    for (auto it = m_pNodes->getChildren().begin(); it!=m_pNodes->getChildren().end(); it++) {
        if ((*it)->getName()=="Sprite_Rabbit") {
            m_pNode_rabbit = (*it);
        }
        
        else{
            m_pNodes_obstacle.pushBack((*it));
        }
        
    }
    
    //添加监听
    auto listener = EventListenerTouchOneByOne::create();
    listener->onTouchBegan = CC_CALLBACK_2(HelloWorld::onTouchBeganCallBack,this);
    Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(listener, this);
    
    //初始化游戏逻辑控制
    m_ctrl = new GameCtrl();
    
    
    //获取UITEXT
    m_pText_curStep = m_pNodes->getChildByName<Text*>("Text_curStep");
    m_pText_bestStep =  m_pNodes->getChildByName<Text*>("Text_bestStep");

    return true;
}

bool HelloWorld::onTouchBeganCallBack(Touch *t, Event* event){
    for (auto it =m_pNodes_obstacle.begin();it!=m_pNodes_obstacle.end() ; it++) {
        if((*it)->getBoundingBox().containsPoint(t->getLocation())&&(!(*it)->isVisible())){
            
            //判断是否失败
            if (m_ctrl->judgeFail()) {
                MessageBox("没办法，AI就是任性", " =.=,兔子跑了!!");
                Director::getInstance()->replaceScene(HelloWorld::createScene());
            }

            //add obt
            auto pObt = (*it);
            pObt->setVisible(true);
            m_ctrl->addObtacle(pObt->getTag());
            
            //判断是否胜利
            if (m_ctrl->judgeSuccess()) {
                if (UserDefault::getInstance()->getIntegerForKey(STR_BEST.c_str())>m_ctrl->getStep()) {
                    UserDefault::getInstance()->setIntegerForKey(STR_BEST.c_str(), m_ctrl->getStep());
                }
                
                //设置messageBox上面显示的信息
                char str_info[60];
                sprintf(str_info, "当前成绩为: %d,最好成绩为: %d",m_ctrl->getStep(),UserDefault::getInstance()->getIntegerForKey(STR_BEST.c_str()));
                MessageBox(str_info, "orz,兔子被围!!");
                Director::getInstance()->replaceScene(HelloWorld::createScene());
            }
            
            //rabbit move
            int moveTag = m_ctrl->rabbitMove();
                if(m_pNodes->getChildByTag(moveTag)){
                     m_pNode_rabbit->runAction(MoveTo::create(0.1, m_pNodes->getChildByTag(moveTag)->getPosition()));
                    //设置Text
                     this->setText(m_pText_curStep,m_ctrl->getStep());
            }
            break;
     }
   }
     return false;
}


void HelloWorld::setRandStones(int num){
    int curNum = 0;
    //随机产生障碍
    while (num!=curNum) {
        int ver,hor,tag;
        ver = 1+rand_0_1()*(NUM_MAPROWANDCOW-2);
        hor = 1+rand_0_1()*(NUM_MAPROWANDCOW-2);
        tag = ver*NUM_MAPROWANDCOW+hor;
        if(!m_pNodes->getChildByTag(tag)->isVisible()&&!(ver==NUM_MAPROWANDCOW/2&&hor==NUM_MAPROWANDCOW/2)){
            m_pNodes->getChildByTag(tag)->setVisible(true);
            m_ctrl->addObtacle(tag);
            curNum++;
        }
        else{
            continue;
        }
        
    }
}
void HelloWorld::setText(Text* pTxt,int num){
    std::stringstream stream;
    stream<<num;
    string str;
    stream>>str;
    if(m_pText_curStep==pTxt){
        pTxt->setString(STR_STEP+str);
    }
    else{
        //如果不是第一次设置
        if(num!=VAL_MAX){
            pTxt->setString(STR_BEST+str);
        }
        else{
            pTxt->setString(STR_BEST);
        }
    }
    
}

void HelloWorld::onEnter(){
    //生成随机的障碍
    this->setRandStones(NUM_INITSTONE+CCRANDOM_0_1()*NUM_DEATALSTONE);
    //设置UI上面Text
    this->setText(m_pText_curStep,m_ctrl->getStep());
    this->setText(m_pText_bestStep,UserDefault::getInstance()->getIntegerForKey(STR_BEST.c_str()));
    Layer::onEnter();
}

void HelloWorld::onExit(){
    Layer::onExit();
    delete m_ctrl;
}

void HelloWorld::menuCloseCallback(Ref* pSender)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WP8) || (CC_TARGET_PLATFORM == CC_PLATFORM_WINRT)
	MessageBox("You pressed the close button. Windows Store Apps do not implement a close button.","Alert");
    return;
#endif

    Director::getInstance()->end();

#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
}
